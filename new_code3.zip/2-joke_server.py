from fastapi import FastAPI
from langchain_community.chat_models import ChatZhipuAI
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from dotenv import dotenv_values
import uvicorn
from langserve import add_routes
import os


def build_chain():
    env_config = dotenv_values(".env")

    os.environ["ZHIPUAI_API_KEY"] = env_config.get("ZHIPUAI_API_KEY")

    llm = ChatZhipuAI()  # 智谱模型

    prompt = ChatPromptTemplate.from_template("讲一个关于{topic}的笑话")

    chain = prompt | llm | StrOutputParser()
    return chain

app = FastAPI(
    title="LangChain Server",
)
add_routes(app, build_chain(), path="/joke")  # 需要打开http://localhost:8000/joke/playground

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
